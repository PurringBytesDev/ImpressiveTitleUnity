This folder contains convenient integrations to host your Mirror games.
All integration(s) are required to be open source C# code with a free tier.
While Mirror is free open source, hosting infrastructure isn't so expect paid tiers for production games.

All integration(s) are completely optional, feel free to delete this folder if you don't need it in your project.